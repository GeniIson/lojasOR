<div class='modal fade' id='vender_m' tabindex='-1' aria-labelledby='Vender_m' aria-hidden='true'>
<div class='modal-dialog'>
  <div class='modal-content'>
    <div class='modal-header'>
      <h5 class='modal-title' id='exampleModalLabel'>Quero vender</h5>
   
   
      <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
    </div>

    

    <p> <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="currentColor" class="bi bi-info-square-fill" viewBox="0 0 16 16">
  <path d="M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2zm8.93 4.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM8 5.5a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
</svg>Esse link esta disponivel para pessoas que deseja vender um aparelho para nossa impresa.</p>



   
      

<h5 class='modal-title' id='exampleModalLabel'style="text-align: center;">É o seu caso?</h5>
<p></p>
         
        
         
         
          <a class='w-100 btn btn-primary btn-purple btn-custom' name='bt_ok' id="bt_ok" value='1' data-bs-dismiss='modal'
             
    data-bs-toggle='modal' 
       data-bs-target='#vender_m1'
       
       >Sim</a>
         
          
        <p></p>
        <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Não</button>
        <br>

    


        </div> 
        
        </div>
      </div>
    </div>

    <div class='modal fade' id='vender_m1' tabindex='-1' aria-labelledby='Vender_m1' aria-hidden='true'>
<div class='modal-dialog'>
  <div class='modal-content'>
    <div class='modal-header' >
      <h5 class='modal-title' id='exampleModalLabel'>Quero vender</h5>
   
   
      <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
    </div>

    

    <h5 class='modal-title' id='exampleModalLabel'style="text-align: center;">Responda 3 perguntas simples?</h5>
<p></p>


   
  
         
        
         
         
          <a class='w-100 btn btn-primary btn-purple btn-custom' name='bt_ok' id="bt_ok" value='1' data-bs-dismiss='modal'
             
    data-bs-toggle='modal' 
       data-bs-target='#vender_m2'
       
       >Ok</a>
         
          
        <p></p>
        <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Cancela</button>
        <br>

    


        </div> 
        
        </div>
      </div>
    </div>


    <div class='modal fade' id='vender_m2' tabindex='-1' aria-labelledby='Vender_m2' aria-hidden='true'>
<div class='modal-dialog'>
  <div class='modal-content'>
    <div class='modal-header'>
      <h5 class='modal-title' id='exampleModalLabel'>Quero vender</h5>
   
   
      <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
    </div>

    
   
  
    <h5 class='modal-title' id='exampleModalLabel'style="text-align: center;">Qual é seu nome?</h5>
<p></p>
         
        
<form id="contactForm">
  
  <input type="text" id="name" name="name" class='form-control' placeholder="Digite aqui seu nome"><br>


 

 
  <a class='w-100 btn btn-primary btn-purple btn-custom' name='bt_ok' id="bt_ok" value='1' data-bs-dismiss='modal'
             
             data-bs-toggle='modal' 
                data-bs-target='#vender_m3'
                
                >Avansar</a>

        <p></p>
        <a class='w-100 btn btn-secondary' data-bs-dismiss='modal'
        data-bs-toggle='modal' 
                data-bs-target='#vender_m1'>Voltar</a>
   <p></p>

    


        </div> 
        
        </div>
      </div>
    </div>


    <div class='modal fade' id='vender_m3' tabindex='-1' aria-labelledby='Vender_m3' aria-hidden='true'>
<div class='modal-dialog'>
  <div class='modal-content'>
    <div class='modal-header'>
      <h5 class='modal-title' id='exampleModalLabel'>Quero vender</h5>
   
   
      <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
    </div>

    

    <h5 class='modal-title' id='exampleModalLabel'style="text-align: center;">Qual Aparelho quer vende?</h5>
<p></p>


 <textarea cols='10' rows='5'  class='form-control' id="message" name="message" placeholder="Digite aqui a descrição com o macimo pocivel de detailhes." required></textarea><br>

         
        
         
 <a class='w-100 btn btn-primary btn-purple btn-custom' name='bt_ok' id="bt_ok" value='1' data-bs-dismiss='modal'
             
             data-bs-toggle='modal' 
                data-bs-target='#vender_m4'
                
                >Avansar</a>

          

          
        <p></p>
        <a class='w-100 btn btn-secondary' data-bs-dismiss='modal'
        data-bs-toggle='modal' 
                data-bs-target='#vender_m2'>Voltar</a>
   <p></p>

    


        </div> 
        
        </div>
      </div>
    </div>

    
    <div class='modal fade' id='vender_m4' tabindex='-1' aria-labelledby='Vender_m4' aria-hidden='true'>
<div class='modal-dialog'>
  <div class='modal-content'>
    <div class='modal-header'>
      <h5 class='modal-title' id='exampleModalLabel'>Quero vender</h5>
   
   
      <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
    </div>

    

    <h5 class='modal-title' id='exampleModalLabel'style="text-align: center;">Por quanto mais ou menos você que vender?</h5>
<p></p>

<input type='number'  class='form-control' step='0.01'  min='0' id="valor" name='valor' placeholder='0,00'>
         
        <p></p>
         
         
               
 <a class='w-100 btn btn-primary btn-purple btn-custom' name='bt_ok' id="bt_ok" value='1' data-bs-dismiss='modal'
             
             data-bs-toggle='modal' 
                data-bs-target='#vender_m5'
                
                >Avansar</a>


          
        <p></p>
        <a class='w-100 btn btn-secondary' data-bs-dismiss='modal'
        data-bs-toggle='modal' 
                data-bs-target='#vender_m3'>Voltar</a>
   <p></p>

    


        </div> 
        
        </div>
      </div>
    </div>


     
    <div class='modal fade' id='vender_m5' tabindex='-1' aria-labelledby='Vender_m5' aria-hidden='true'>
<div class='modal-dialog'>
  <div class='modal-content'>
    <div class='modal-header'>
      <h5 class='modal-title' id='exampleModalLabel'>Quero vender</h5>
   
   
      <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
    </div>

    

    <h5 class='modal-title' id='exampleModalLabel'style="text-align: center;">Muito obrigado pelas respostas!</h5>
<p>Você vai ser direcionado para fazer negocio em nosso whatsapp e sera atendido por um de nossos compradores, não se esqueça de clicar enviar em seu watzap!</p>


         
        
         
         
          <button type='submit'class='w-100 btn btn-primary btn-purple btn-custom' name='bt_ok' id="bt_ok" value='1' data-bs-dismiss='modal'>Finalizar</button>

          
</form>
          
    
          
        <p></p>
        <a class='w-100 btn btn-secondary' data-bs-dismiss='modal'
        data-bs-toggle='modal' 
                data-bs-target='#vender_m4'>Voltar</a>
   <p></p>
    


        </div> 
        
        </div>
      </div>
    </div>







<script src="../assets/js/bootstrap.bundle.min.js"></script>







<script>
  document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Impede o envio padrão do formulário

    // Obtém os valores dos campos do formulário
    var name = document.getElementById("name").value;
  
    var valor = document.getElementById("valor").value;
    var descricao = document.getElementById("message").value;

    var message = "Olá tudo bem?,\b\b*Quero vender*\b\b\n Nome: _" + name +"_\n Descrição: _" + descricao + "_\n Valor: *" +valor+"*" ;
    
    
 

    // Monta o link do WhatsApp com os dados do formulário
    var whatsappLink = "https://api.whatsapp.com/send?phone=" + 5587981492269 + "&text=" + encodeURIComponent(message);

    // Redireciona para o link do WhatsApp
    window.open(whatsappLink, "_blank");
  });
</script>

