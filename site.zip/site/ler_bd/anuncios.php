








<div class="col mb-5" style="padding: 10px;margin: 0;">
                        <div class="card h-100" style="padding: -10px; margin: 0px; ">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Promoção</div>
                            
                            <!-- Product image-->
                            <a href="?produto=<?=$id_an?>">
                            <img class="card-img-top" src="../../arquivos_fixos_importante_or/capas/<?=$capa_arquivo?>" alt="..." /></a>
                            <!-- Product details-->
                            <div class="card-body p-4" style="padding: -10px; margin: 0px; ">
                                <div class="text-center" style="padding: -10px; margin: 0px; ">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder" style="padding: -10px; margin: 0px; "><?=$descricao?></h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>
                                    <!-- Product price-->
                                  De  <span class="text-muted text-decoration-line-through" style="padding: -10px; margin: 0px; "><?=$valor_novo?></span> <br>Por
                                    <?=$valor_venda?>
                                </div>
                            </div>
                            <!-- Product actions-->

                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent" style="padding: -10px; margin: 0px; ">
                             


<div class="text-center"style="padding: -10px; margin: 0px; "><a class="btn btn-outline-dark mt-auto" href="?produto=<?=$id_an?>">
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-zoom-out" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z"/>
  <path d="M10.344 11.742c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1 6.538 6.538 0 0 1-1.398 1.4z"/>
  <path fill-rule="evenodd" d="M3 6.5a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5z"/>
</svg>


Comferir</a>

</div>
                            </div> 



                            
                        </div>
                    </div>
                   