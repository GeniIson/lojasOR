<div style="position: fixed; top:20%;" id='vender_m6' tabindex='-1' aria-labelledby='Vender_m6' aria-hidden='true'>
    
    
    <div class='modal-dialog'>
    <div class='modal-content'>
      <div class='modal-header'>
        <h5 class='modal-title' id='exampleModalLabel'>Quero vender</h5>
        <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
      </div>
      <div class='modal-body'>
        <p>Clique no botão abaixo para enviar a mensagem:</p>
        <a class='w-100 btn btn-primary btn-purple btn-custom' name='bt_ok' id='bt_ok' value='1' data-bs-dismiss='modal' target='_blank'>Enviar Mensagem</a>
      </div>
    </div>
    </div> </div>