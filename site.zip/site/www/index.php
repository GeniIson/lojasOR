


<?php


header('Location:../../../www');