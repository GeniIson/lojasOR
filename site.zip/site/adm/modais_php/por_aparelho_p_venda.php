


<div style='position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color:#0000008f; z-index: 9999;'>
<span style=' float:right;'>
<a id='lacar_valor'  class='btn btn-outline-success'href='?x'
      
      style= 'text-decoration: none;background-color:black;color:white;border-radius: 100%;'
      
      >X</a>
    
    </span>
    <br>
<div class='container marketing'  style='  background-color:#ffffffe8; border-radius: 20px;'>
<div class='row'  >

<div class='row g-12'>
<span style=' float:right;'>
<a  class='btn btn-outline-success'href='?valores=<?=$idOs?>&modal1'
      
data-bs-toggle='modal' 
data-bs-target='#exampleModalproduto9' 
     
      
     
      
      >novo+</a>
    
    </span>



    <table style= 'font-size: 14px; border-collapse: collapse;' class='table table-bordered table-condensed'>
      
    <thead>
    
        <tr>
        
        
       
        
        <th colspan='1'style='text-align: center;'>Estoque</th>
        <th colspan='1'style='text-align: center;'>Presço de Compra</th> 
       
        <th colspan='2'style='text-align: center;'> Produtos</th>
        <th colspan='1'style='text-align: center;'>Preço de venda</th>
        <th colspan='1'style='text-align: center;'>Categoria</th>
           
           
          
         
  
    
      
            
        </tr>
    </thead> 
    <tbody>
    
                     
 
    
    
   <?php 
    
    include 'pull/produto_tabela.php';
    
    ?>  
       
        
    </table>




    

    </div></div></div></div>";
  

